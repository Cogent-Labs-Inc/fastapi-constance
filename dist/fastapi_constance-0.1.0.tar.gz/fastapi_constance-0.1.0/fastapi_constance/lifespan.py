from contextlib import asynccontextmanager
from fastapi import FastAPI
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi_constance.utils import sync_app_settings
from fastapi_constance.models import ConstanceConfig
from fastapi_constance.wrapper import ConstanceConfigWrapper

constance_config = ConstanceConfigWrapper()

@asynccontextmanager
async def lifespan(app: FastAPI, session: AsyncSession, user_config: dict):
    async with session.bind.begin() as conn:
        await conn.run_sync(ConstanceConfig.metadata.create_all)

    # Initialize manager
    manager = await sync_app_settings(session, user_config)
    app.state.config_manager = manager
    constance_config.set_manager(manager)

    yield  # Control passes to FastAPI
